"""Streamlit interface for LegalEase."""
from __future__ import annotations

import html
import os
import sys
from datetime import date
from pathlib import Path

import requests
import streamlit as st
from dotenv import load_dotenv

ROOT_DIR = Path(__file__).resolve().parents[1]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))
load_dotenv(ROOT_DIR / ".env")

from backend.services.document_formatter import (  # noqa: E402
    build_filename,
    format_docx,
    format_html_preview,
    format_pdf,
    format_txt,
)

API_URL = os.getenv("LEGAL_EASE_API_URL", "http://127.0.0.1:8000").rstrip("/")
LOGO_PATH = Path(__file__).parent / "assets" / "legalease-logo.svg"

st.set_page_config(page_title="LegalEase | Legal Document Drafting", page_icon="⚖️", layout="wide")
st.markdown(
    """
    <style>
      .stApp { background: #f5f7fb; }
      .block-container { max-width: 1180px; padding-top: 1.5rem; padding-bottom: 3rem; }
      .hero { background: linear-gradient(120deg, #18365c 0%, #284f79 100%); color: white;
              padding: 1.4rem 1.6rem; border-radius: 18px; margin-bottom: 1.2rem; }
      .hero h1 { margin: 0; font-size: 2rem; }
      .hero p { color: #dbe8f6; margin: .45rem 0 0; }
      .legal-preview { overflow-wrap: anywhere; max-height: 700px; overflow-y: auto;
                       background: #ffffff; border: 1px solid #dce3ed; border-radius: 12px;
                       padding: 1.1rem 1.2rem; color: #202b3b; font: 14px/1.65 system-ui, -apple-system, Segoe UI, sans-serif; }
      .legal-preview h1, .legal-preview h2, .legal-preview h3 { color: #18365c; line-height: 1.3; }
      .legal-preview h1 { font-size: 1.55rem; }
      .legal-preview h2 { font-size: 1.18rem; margin-top: 1.2rem; }
      .legal-preview h3 { font-size: 1.05rem; margin-top: 1rem; }
      .legal-preview p { margin: .55rem 0; }
      .legal-preview li { margin: .25rem 0; }
      div[data-testid="stForm"] { background: #ffffff; border: 1px solid #e1e7ef; border-radius: 14px; padding: 1rem; }
      .small-muted { color: #53657c; font-size: .9rem; }
    </style>
    """,
    unsafe_allow_html=True,
)

if "document_text" not in st.session_state:
    st.session_state.document_text = ""
if "generation_mode" not in st.session_state:
    st.session_state.generation_mode = ""
if "generation_model" not in st.session_state:
    st.session_state.generation_model = ""
if "generation_warning" not in st.session_state:
    st.session_state.generation_warning = ""
if "editor_value" not in st.session_state:
    st.session_state.editor_value = ""
if "current_doc_type" not in st.session_state:
    st.session_state.current_doc_type = "Legal Document"
if "generated_terms" not in st.session_state:
    st.session_state.generated_terms = []

try:
    logo_svg = LOGO_PATH.read_text(encoding="utf-8")
    st.markdown(f'<div style="max-width:420px;margin:0 auto 1rem">{logo_svg}</div>', unsafe_allow_html=True)
except OSError:
    pass

st.markdown(
    '<div class="hero"><h1>Draft legal documents with more clarity.</h1>'
    '<p>Create an editable first draft, review it, and export it in a professional format.</p></div>',
    unsafe_allow_html=True,
)
st.caption("LegalEase is a drafting aid, not a lawyer. Always verify the draft with qualified legal counsel.")

left, right = st.columns([0.92, 1.08], gap="large")
with left:
    st.subheader("Document details")
    document_types = [
        "Employment Contract",
        "Non-Disclosure Agreement (NDA)",
        "Residential Lease Agreement",
        "Freelance Work Contract",
        "Service Agreement",
        "Employment Offer Letter",
        "General Agreement",
        "Other / custom",
    ]
    with st.form("document_request_form", clear_on_submit=False):
        chosen_type = st.selectbox("Document type", document_types, index=0)
        custom_type = st.text_input(
            "Custom document type (only needed for Other / custom)",
            placeholder="e.g., Consultancy Agreement",
        )
        parties = st.text_area(
            "Parties involved *",
            placeholder="Jane Doe (Service Provider); TechNova Inc. (Client)",
            height=95,
            help="Include each party's name and role. Avoid adding unnecessary sensitive personal data.",
        )
        terms_text = st.text_area(
            "Terms & conditions",
            placeholder="Payment within 30 days of invoice; Confidentiality must be maintained; Either party may terminate with 15 days notice",
            height=125,
            help="Separate clauses with semicolons or place one clause per line.",
        )
        date_col, jurisdiction_col = st.columns(2)
        with date_col:
            effective_date = st.date_input("Effective date *", value=date.today())
        with jurisdiction_col:
            jurisdiction = st.text_input("Jurisdiction / governing law", placeholder="e.g., India")
        additional_instructions = st.text_area(
            "Additional instructions (optional)",
            placeholder="Tone, missing details to flag, special clauses to consider...",
            height=90,
        )
        submitted = st.form_submit_button("Generate document", type="primary", use_container_width=True)

    st.subheader("Branding for downloads")
    company_name = st.text_input("Company / brand name", value="LegalEase")
    footer_text = st.text_input("Footer text", value="Draft for review only - not legal advice")
    uploaded_logo = st.file_uploader("Optional company logo (PNG or JPG)", type=["png", "jpg", "jpeg"])
    logo_bytes = uploaded_logo.getvalue() if uploaded_logo else None

    if submitted:
        final_type = custom_type.strip() if chosen_type == "Other / custom" else chosen_type
        if not final_type:
            st.error("Please enter a custom document type.")
        elif len(parties.strip()) < 2:
            st.error("Please provide the names and roles of the parties.")
        else:
            payload = {
                "document_type": final_type,
                "parties": parties.strip(),
                "terms": terms_text,
                "effective_date": effective_date.isoformat(),
                "jurisdiction": jurisdiction.strip() or "Not specified",
                "additional_instructions": additional_instructions.strip(),
            }
            try:
                with st.spinner("Preparing your draft..."):
                    response = requests.post(f"{API_URL}/generate", json=payload, timeout=180)
                if response.ok:
                    result = response.json()
                    st.session_state.document_text = result["document_text"]
                    st.session_state.editor_value = result["document_text"]
                    st.session_state.generation_mode = result.get("mode", "")
                    st.session_state.generation_model = result.get("model", "")
                    st.session_state.generation_warning = result.get("warning", "")
                    st.session_state.current_doc_type = final_type
                    st.session_state.generated_terms = [
                        item.strip()
                        for item in terms_text.replace("\r", "\n").replace(";", "\n").split("\n")
                        if item.strip()
                    ]
                    st.success("Draft generated. Review and edit it before downloading.")
                else:
                    try:
                        detail = response.json().get("detail", response.text)
                    except ValueError:
                        detail = response.text
                    st.error(f"Backend error ({response.status_code}): {detail}")
            except requests.RequestException:
                st.error(
                    "Cannot reach the FastAPI backend. Start it in a separate terminal with "
                    "`uvicorn backend.main:app --reload --port 8000`."
                )

with right:
    st.subheader("Your document")
    if st.session_state.document_text:
        if st.session_state.generation_mode == "demo":
            st.warning("Demo Mode — this is an illustrative local template, not generated by AI.")
        elif st.session_state.generation_mode == "gemini":
            st.info(f"Generated with Gemini model: {st.session_state.generation_model}")
        if st.session_state.generation_warning:
            with st.expander("Important legal-use notice", expanded=True):
                st.write(st.session_state.generation_warning)

        preview_tab, edit_tab = st.tabs(["Preview", "Edit & export"])
        with preview_tab:
            safe_preview = format_html_preview(st.session_state.editor_value)
            st.markdown(f'<div class="legal-preview">{safe_preview}</div>', unsafe_allow_html=True)
        with edit_tab:
            st.text_area(
                "Editable draft text",
                key="editor_value",
                height=520,
                help="Changes here are applied to downloaded files. The original input values remain unchanged.",
            )
            current_text = st.session_state.editor_value
            current_terms = st.session_state.generated_terms
            final_type_for_name = st.session_state.current_doc_type
            d1, d2, d3 = st.columns(3)
            with d1:
                st.download_button(
                    "Download TXT",
                    data=format_txt(current_text, company_name),
                    file_name=build_filename(final_type_for_name, "txt"),
                    mime="text/plain",
                    use_container_width=True,
                )
            with d2:
                docx_bytes = format_docx(current_text, final_type_for_name, current_terms, logo_bytes, company_name, footer_text)
                st.download_button(
                    "Download DOCX",
                    data=docx_bytes,
                    file_name=build_filename(final_type_for_name, "docx"),
                    mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                    use_container_width=True,
                )
            with d3:
                pdf_bytes = format_pdf(current_text, final_type_for_name, current_terms, logo_bytes, company_name, footer_text)
                st.download_button(
                    "Download PDF",
                    data=pdf_bytes,
                    file_name=build_filename(final_type_for_name, "pdf"),
                    mime="application/pdf",
                    use_container_width=True,
                )
        if st.button("Clear current draft", use_container_width=False):
            st.session_state.document_text = ""
            st.session_state.editor_value = ""
            st.session_state.generation_mode = ""
            st.session_state.generation_model = ""
            st.session_state.generation_warning = ""
            st.session_state.current_doc_type = "Legal Document"
            st.session_state.generated_terms = []
            st.rerun()
    else:
        st.markdown(
            '<div class="legal-preview">Your generated draft will appear here. Complete the fields on the left and select “Generate document”.</div>',
            unsafe_allow_html=True,
        )
        st.markdown('<p class="small-muted">Tip: more specific terms and party roles help produce a more useful first draft.</p>', unsafe_allow_html=True)

st.divider()
st.caption("Privacy note: the app does not include database persistence. With live Gemini enabled, request content is sent to the configured Google AI service for generation. Review provider terms and your organisation's policies before using confidential information.")
