# LegalEase verification report

Date: 2026-10-12

## Automated tests

Command: `pytest -q`

Result: **10 passed**

Covered:
- FastAPI health endpoint and local demo generation.
- Term-string parsing and request validation.
- TXT export and DOCX/PDF parseability.
- PDF and DOCX exports with an uploaded logo.
- Safe HTML preview escaping.
- Supported download filename extensions.

## Local process smoke test

Started Uvicorn on a temporary local port and verified:
- `GET /health` returned HTTP 200.
- `POST /generate` returned HTTP 200 in demo mode with a non-empty draft.

## Manual PDF layout check

Rendered a representative branded PDF to PNG and visually checked the first page and terms appendix. Headings, wrapping, logo placement, footer, and page numbers rendered correctly.

## Not verified in this sandbox

The sandbox had no package-network access, and Streamlit plus `google-genai` were not installed. As a result, the Streamlit page could not be launched here and no live Gemini API request was made. These packages are listed in `requirements.txt`; install them on your machine before running the complete UI/live AI path. Demo-mode backend and export tests do not require a Gemini API key.
