"""API endpoints for generating legal document drafts."""
from fastapi import APIRouter, HTTPException

from backend.ai_core.gemini_generator import (
    AIConfigurationError,
    AIGenerationError,
    GeminiDocumentGenerator,
)
from backend.models import DocumentRequest, DocumentResponse

router = APIRouter()
_generator = GeminiDocumentGenerator()


@router.post("/generate", response_model=DocumentResponse, summary="Generate a draft legal document")
def generate_document(payload: DocumentRequest) -> DocumentResponse:
    try:
        result = _generator.generate_document(payload)
    except AIConfigurationError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except AIGenerationError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    return DocumentResponse(
        document_text=result.document_text,
        mode=result.mode,  # type: ignore[arg-type]
        model=result.model,
        warning=result.warning,
    )
