"""LegalEase FastAPI backend package."""
