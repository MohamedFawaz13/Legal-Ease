"""TXT, DOCX and PDF export helpers with optional user-supplied branding."""
from __future__ import annotations

import html
import io
import re
import unicodedata
from pathlib import Path
from typing import Iterable

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Inches, Pt, RGBColor
from fpdf import FPDF
from PIL import Image


LEGAL_BLUE = RGBColor(28, 54, 92)


def _clean_terms(terms: Iterable[str] | None) -> list[str]:
    return [str(term).strip() for term in (terms or []) if str(term).strip()]


def _safe_filename(value: str) -> str:
    value = re.sub(r"[^a-zA-Z0-9]+", "_", value.strip().lower()).strip("_")
    return (value[:60] or "legal_document")


def format_html_preview(text: str) -> str:
    """Render the supported Markdown subset as safe, escaped HTML for the UI preview."""
    output: list[str] = []
    paragraph: list[str] = []
    bullets: list[str] = []
    numbered: list[str] = []

    def inline_markup(value: str) -> str:
        safe = html.escape(value, quote=True)
        safe = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", safe)
        safe = re.sub(r"(?<!\*)\*([^*]+)\*(?!\*)", r"<em>\1</em>", safe)
        return safe

    def flush_paragraph() -> None:
        if paragraph:
            output.append("<p>" + " ".join(inline_markup(part) for part in paragraph) + "</p>")
            paragraph.clear()

    def flush_bullets() -> None:
        if bullets:
            output.append("<ul>" + "".join(f"<li>{inline_markup(item)}</li>" for item in bullets) + "</ul>")
            bullets.clear()

    def flush_numbered() -> None:
        if numbered:
            output.append("<ol>" + "".join(f"<li>{inline_markup(item)}</li>" for item in numbered) + "</ol>")
            numbered.clear()

    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            flush_paragraph()
            flush_bullets()
            flush_numbered()
        elif line in {"---", "***"}:
            flush_paragraph(); flush_bullets(); flush_numbered()
            output.append("<hr>")
        elif line.startswith("### "):
            flush_paragraph(); flush_bullets(); flush_numbered()
            output.append(f"<h3>{inline_markup(line[4:].strip())}</h3>")
        elif line.startswith("## "):
            flush_paragraph(); flush_bullets(); flush_numbered()
            output.append(f"<h2>{inline_markup(line[3:].strip())}</h2>")
        elif line.startswith("# "):
            flush_paragraph(); flush_bullets(); flush_numbered()
            output.append(f"<h1>{inline_markup(line[2:].strip())}</h1>")
        elif re.match(r"^[-*]\s+", line):
            flush_paragraph(); flush_numbered()
            bullets.append(re.sub(r"^[-*]\s+", "", line))
        elif re.match(r"^\d+[.)]\s+", line):
            flush_paragraph(); flush_bullets()
            numbered.append(re.sub(r"^\d+[.)]\s+", "", line))
        else:
            flush_bullets(); flush_numbered()
            paragraph.append(line)
    flush_paragraph(); flush_bullets(); flush_numbered()
    return "\n".join(output)


def format_txt(text: str, company_name: str = "LegalEase") -> bytes:
    content = text.strip()
    if company_name.strip():
        content += f"\n\n---\nPrepared with {company_name.strip()} — draft for review.\n"
    return content.encode("utf-8")


def format_docx(
    text: str,
    doc_type: str = "Legal Document",
    terms: Iterable[str] | None = None,
    logo_bytes: bytes | None = None,
    company_name: str = "LegalEase",
    footer_text: str = "Draft for review only - not legal advice",
) -> bytes:
    doc = Document()
    section = doc.sections[0]
    section.top_margin = Inches(0.75)
    section.bottom_margin = Inches(0.7)
    section.left_margin = Inches(0.85)
    section.right_margin = Inches(0.85)

    styles = doc.styles
    styles["Normal"].font.name = "Times New Roman"
    styles["Normal"].font.size = Pt(11)
    styles["Normal"].paragraph_format.space_after = Pt(6)
    for name in ("Title", "Heading 1", "Heading 2"):
        styles[name].font.name = "Times New Roman"
        styles[name].font.color.rgb = LEGAL_BLUE
    styles["Title"].font.size = Pt(19)
    styles["Heading 1"].font.size = Pt(14)
    styles["Heading 2"].font.size = Pt(12)

    header = section.header
    header_p = header.paragraphs[0]
    header_p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    if logo_bytes:
        try:
            header_p.add_run().add_picture(io.BytesIO(logo_bytes), width=Inches(0.8))
        except Exception:
            # A malformed/unsupported logo should not prevent document export.
            header_p.add_run(company_name.strip() or "LegalEase")
    else:
        header_p.add_run(company_name.strip() or "LegalEase").bold = True

    # Parse a useful subset of Markdown and render as native Word paragraphs/lists.
    first_nonempty = next((line.strip() for line in text.splitlines() if line.strip()), "")
    if not first_nonempty.startswith("# "):
        doc.add_heading(doc_type.strip() or "Legal Document", level=0)
    for raw_line in text.splitlines():
        line = raw_line.rstrip()
        stripped = line.strip()
        if not stripped:
            continue
        if stripped.startswith("### "):
            doc.add_heading(stripped[4:].strip(), level=2)
        elif stripped.startswith("## "):
            doc.add_heading(stripped[3:].strip(), level=1)
        elif stripped.startswith("# "):
            doc.add_heading(stripped[2:].strip(), level=0)
        elif re.match(r"^[-*]\s+", stripped):
            doc.add_paragraph(re.sub(r"^[-*]\s+", "", stripped), style="List Bullet")
        elif re.match(r"^\d+[.)]\s+", stripped):
            doc.add_paragraph(re.sub(r"^\d+[.)]\s+", "", stripped), style="List Number")
        elif stripped in {"---", "***"}:
            p = doc.add_paragraph()
            p.paragraph_format.space_after = Pt(2)
            run = p.add_run("────────────────────────────────────────")
            run.font.color.rgb = RGBColor(170, 180, 195)
        else:
            # Preserve the generated wording while removing simple Markdown emphasis markers.
            cleaned = re.sub(r"\*\*(.+?)\*\*", r"\1", stripped)
            cleaned = re.sub(r"(?<!\*)\*([^*]+)\*(?!\*)", r"\1", cleaned)
            doc.add_paragraph(cleaned)

    clean = _clean_terms(terms)
    if clean:
        doc.add_page_break()
        doc.add_heading("Appendix: Key Terms Provided", level=1)
        table = doc.add_table(rows=1, cols=2)
        table.style = "Light Shading Accent 1"
        table.rows[0].cells[0].text = "No."
        table.rows[0].cells[1].text = "Term"
        for index, term in enumerate(clean, start=1):
            cells = table.add_row().cells
            cells[0].text = str(index)
            cells[1].text = term

    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    footer.add_run(footer_text.strip() or "Draft for review only")
    footer.add_run("  |  Page ")
    footer._p.append(_make_page_field())

    buffer = io.BytesIO()
    doc.save(buffer)
    return buffer.getvalue()


def _make_page_field():
    """Create a Word PAGE field element without external template files."""
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn

    field = OxmlElement("w:fldSimple")
    field.set(qn("w:instr"), "PAGE")
    run = OxmlElement("w:r")
    text = OxmlElement("w:t")
    text.text = "1"
    run.append(text)
    field.append(run)
    return field


def _find_font_pair() -> tuple[str, str] | None:
    candidates = [
        ("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"),
        ("/usr/share/fonts/dejavu/DejaVuSans.ttf", "/usr/share/fonts/dejavu/DejaVuSans-Bold.ttf"),
        ("C:/Windows/Fonts/arial.ttf", "C:/Windows/Fonts/arialbd.ttf"),
        ("/Library/Fonts/Arial.ttf", "/Library/Fonts/Arial Bold.ttf"),
    ]
    for regular, bold in candidates:
        if Path(regular).exists() and Path(bold).exists():
            return regular, bold
    return None


def _logo_as_png(logo_bytes: bytes) -> bytes:
    with Image.open(io.BytesIO(logo_bytes)) as img:
        image = img.convert("RGBA")
        output = io.BytesIO()
        image.save(output, format="PNG")
        return output.getvalue()


def _pdf_text_safe(text: str, unicode_font: bool) -> str:
    if unicode_font:
        return text
    # Fallback for machines without an installed Unicode font.
    replacements = {"—": "-", "–": "-", "’": "'", "‘": "'", "“": '"', "”": '"', "•": "-", "→": "->"}
    for old, new in replacements.items():
        text = text.replace(old, new)
    return unicodedata.normalize("NFKD", text).encode("latin-1", errors="replace").decode("latin-1")


class _LegalEasePDF(FPDF):
    def __init__(self, *args, logo_png: bytes | None = None, company_name: str = "LegalEase", footer_text: str = "Draft for review only - not legal advice", **kwargs):
        super().__init__(*args, **kwargs)
        self.logo_png = logo_png
        self.company_name = company_name.strip() or "LegalEase"
        self.footer_text = footer_text.strip() or "Draft for review only"
        self.unicode_font = False

    def header(self) -> None:
        self.set_y(8)
        if self.logo_png:
            try:
                self.image(io.BytesIO(self.logo_png), x=15, y=7, w=18)
            except Exception:
                pass
        self.set_font("LegalEaseFont", "B", 9) if self.unicode_font else self.set_font("Helvetica", "B", 9)
        self.set_text_color(28, 54, 92)
        self.set_xy(37 if self.logo_png else 15, 10)
        self.cell(0, 6, self.company_name, align="L")
        self.set_draw_color(205, 214, 226)
        self.line(15, 25, 195, 25)
        self.set_y(30)

    def footer(self) -> None:
        self.set_y(-15)
        self.set_draw_color(205, 214, 226)
        self.line(15, self.get_y(), 195, self.get_y())
        self.set_y(-12)
        self.set_font("LegalEaseFont", "", 8) if self.unicode_font else self.set_font("Helvetica", "", 8)
        self.set_text_color(95, 105, 120)
        footer_line = _pdf_text_safe(self.footer_text, self.unicode_font)
        self.cell(140, 6, footer_line[:120], align="L")
        self.cell(40, 6, f"Page {self.page_no()}/{{nb}}", align="R")


def format_pdf(
    text: str,
    doc_type: str = "Legal Document",
    terms: Iterable[str] | None = None,
    logo_bytes: bytes | None = None,
    company_name: str = "LegalEase",
    footer_text: str = "Draft for review only - not legal advice",
) -> bytes:
    logo_png = _logo_as_png(logo_bytes) if logo_bytes else None
    pdf = _LegalEasePDF(orientation="P", unit="mm", format="A4", logo_png=logo_png, company_name=company_name, footer_text=footer_text)
    pdf.set_margins(15, 30, 15)
    pdf.set_auto_page_break(auto=True, margin=19)
    pdf.alias_nb_pages()

    fonts = _find_font_pair()
    if fonts:
        pdf.add_font("LegalEaseFont", "", fonts[0])
        pdf.add_font("LegalEaseFont", "B", fonts[1])
        pdf.unicode_font = True

    pdf.add_page()
    normal_font = "LegalEaseFont" if pdf.unicode_font else "Helvetica"
    safe_text = _pdf_text_safe(text.strip(), pdf.unicode_font)
    title_written = False
    for raw_line in safe_text.splitlines():
        # FPDF2 may leave the cursor at the right margin after multi_cell; reset for each paragraph.
        pdf.set_x(pdf.l_margin)
        line = raw_line.strip()
        if not line:
            pdf.ln(2.3)
            pdf.set_x(pdf.l_margin)
            continue
        if line.startswith("### "):
            pdf.ln(1)
            pdf.set_font(normal_font, "B", 11)
            pdf.set_text_color(28, 54, 92)
            pdf.multi_cell(0, 6, line[4:].strip())
            pdf.set_text_color(35, 40, 48)
        elif line.startswith("## "):
            pdf.ln(1.5)
            pdf.set_font(normal_font, "B", 13)
            pdf.set_text_color(28, 54, 92)
            pdf.multi_cell(0, 7, line[3:].strip())
            pdf.set_text_color(35, 40, 48)
        elif line.startswith("# "):
            pdf.set_font(normal_font, "B", 18)
            pdf.set_text_color(28, 54, 92)
            pdf.multi_cell(0, 10, line[2:].strip())
            pdf.set_text_color(35, 40, 48)
            pdf.ln(2)
            title_written = True
        elif line.startswith("- ") or line.startswith("* "):
            pdf.set_font(normal_font, "", 10)
            pdf.set_x(19)
            pdf.multi_cell(0, 5.5, "- " + line[2:].strip())
        elif re.match(r"^\d+[.)]\s+", line):
            pdf.set_font(normal_font, "", 10)
            pdf.multi_cell(0, 5.5, line)
        elif line in {"---", "***"}:
            pdf.set_draw_color(190, 200, 214)
            y = pdf.get_y() + 1
            pdf.line(15, y, 195, y)
            pdf.ln(4)
        else:
            clean = re.sub(r"\*\*(.+?)\*\*", r"\1", line)
            clean = re.sub(r"(?<!\*)\*([^*]+)\*(?!\*)", r"\1", clean)
            pdf.set_font(normal_font, "", 10)
            pdf.set_text_color(35, 40, 48)
            pdf.multi_cell(0, 5.5, clean)
    if not title_written:
        # The generated body remains first; no duplicated title is inserted unless needed.
        pass

    clean_terms = _clean_terms(terms)
    if clean_terms:
        pdf.add_page()
        pdf.set_font(normal_font, "B", 14)
        pdf.set_text_color(28, 54, 92)
        pdf.multi_cell(0, 8, "Appendix: Key Terms Provided")
        pdf.ln(2)
        for index, term in enumerate(clean_terms, start=1):
            pdf.set_x(pdf.l_margin)
            pdf.set_font(normal_font, "B", 10)
            pdf.cell(10, 6, f"{index}.")
            pdf.set_font(normal_font, "", 10)
            pdf.multi_cell(0, 6, _pdf_text_safe(term, pdf.unicode_font))
            pdf.ln(1)

    result = pdf.output()
    return bytes(result)


def build_filename(doc_type: str, extension: str) -> str:
    extension = extension.lstrip(".").lower()
    if extension not in {"txt", "docx", "pdf"}:
        raise ValueError("Supported extensions are txt, docx, pdf")
    return f"{_safe_filename(doc_type)}.{extension}"
