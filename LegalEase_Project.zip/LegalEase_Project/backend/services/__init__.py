"""Shared backend services."""
