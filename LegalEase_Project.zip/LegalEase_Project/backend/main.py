"""FastAPI application entry point."""
from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

ROOT_DIR = Path(__file__).resolve().parents[1]
load_dotenv(ROOT_DIR / ".env")

from backend.routes import router  # noqa: E402

app = FastAPI(
    title="LegalEase API",
    description=(
        "AI-assisted first-draft legal document generation. Outputs require review by a qualified lawyer."
    ),
    version="1.0.0",
)

origins_raw = os.getenv(
    "LEGAL_EASE_ALLOWED_ORIGINS",
    "http://localhost:8501,http://127.0.0.1:8501",
)
allowed_origins = [origin.strip() for origin in origins_raw.split(",") if origin.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type", "Authorization"],
)
app.include_router(router)


@app.get("/", tags=["health"])
def root() -> dict[str, str]:
    return {"service": "LegalEase API", "status": "running", "docs": "/docs"}


@app.get("/health", tags=["health"])
def health() -> dict[str, str]:
    return {"status": "ok", "service": "LegalEase API"}
