"""Validated request and response schemas for LegalEase."""
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field, field_validator


class DocumentRequest(BaseModel):
    document_type: str = Field(min_length=2, max_length=100, description="Type of legal document")
    parties: str = Field(min_length=2, max_length=2_000, description="Names and roles of parties")
    terms: list[str] = Field(default_factory=list, max_length=30, description="Key clauses or agreed terms")
    effective_date: str = Field(min_length=3, max_length=80)
    jurisdiction: str = Field(default="Not specified", max_length=150)
    additional_instructions: str = Field(default="", max_length=2_000)

    @field_validator("document_type", "parties", "effective_date", mode="before")
    @classmethod
    def trim_required_text(cls, value: object) -> object:
        return value.strip() if isinstance(value, str) else value

    @field_validator("jurisdiction", "additional_instructions", mode="before")
    @classmethod
    def trim_optional_text(cls, value: object) -> object:
        return value.strip() if isinstance(value, str) else value

    @field_validator("terms", mode="before")
    @classmethod
    def normalize_terms(cls, value: object) -> list[str]:
        if value is None:
            return []
        if isinstance(value, str):
            candidates = value.replace("\r", "\n").replace(";", "\n").split("\n")
        elif isinstance(value, list):
            candidates = value
        else:
            raise ValueError("terms must be a list or semicolon-separated string")

        cleaned: list[str] = []
        for item in candidates:
            if not isinstance(item, str):
                raise ValueError("each term must be text")
            term = item.strip().lstrip("-• ").strip()
            if term:
                if len(term) > 500:
                    raise ValueError("each term must be 500 characters or fewer")
                cleaned.append(term)
        if len(cleaned) > 30:
            raise ValueError("provide no more than 30 terms")
        return cleaned


class DocumentResponse(BaseModel):
    document_text: str
    mode: Literal["gemini", "demo"]
    model: str
    warning: str
