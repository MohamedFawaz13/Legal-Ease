"""FastAPI smoke tests run in labelled demo mode; no external API calls."""
import os

from fastapi.testclient import TestClient

os.environ["LEGAL_EASE_DEMO_MODE"] = "true"
os.environ.pop("GEMINI_API_KEY", None)
os.environ.pop("GOOGLE_API_KEY", None)

from backend.main import app  # noqa: E402

client = TestClient(app)


def test_health_endpoint():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_generate_demo_document():
    response = client.post(
        "/generate",
        json={
            "document_type": "Freelance Work Contract",
            "parties": "Jane Doe (Service Provider); Example Ltd (Client)",
            "terms": "Payment in 30 days; Confidentiality applies",
            "effective_date": "2026-10-12",
            "jurisdiction": "India",
        },
    )
    assert response.status_code == 200
    result = response.json()
    assert result["mode"] == "demo"
    assert "Jane Doe" in result["document_text"]
    assert "Payment in 30 days" in result["document_text"]
    assert "Demo Mode" in result["warning"]


def test_terms_string_normalization():
    response = client.post(
        "/generate",
        json={
            "document_type": "NDA",
            "parties": "Person A and Person B",
            "terms": "Confidentiality; Return information\nNo public disclosure",
            "effective_date": "2026-10-12",
        },
    )
    assert response.status_code == 200
    document = response.json()["document_text"]
    assert "Confidentiality" in document
    assert "Return information" in document
    assert "No public disclosure" in document


def test_invalid_request_is_rejected():
    response = client.post("/generate", json={"document_type": "NDA"})
    assert response.status_code == 422
