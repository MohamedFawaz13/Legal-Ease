"""Local export tests ensure the generators produce valid file containers."""
from io import BytesIO

from PIL import Image

from docx import Document
from pypdf import PdfReader

from backend.services.document_formatter import build_filename, format_docx, format_html_preview, format_pdf, format_txt

SAMPLE = """# NON-DISCLOSURE AGREEMENT

## 1. Parties
Party A and Party B.

## 2. Confidential Information
- Keep confidential information private.
- Return documents on request.

## Items to Confirm Before Signing
Confirm addresses and duration.
"""


def test_txt_output_is_utf8():
    content = format_txt(SAMPLE, "Example Co")
    assert b"NON-DISCLOSURE AGREEMENT" in content
    assert "Example Co" in content.decode("utf-8")


def test_docx_output_is_readable_and_contains_text():
    content = format_docx(SAMPLE, "NDA", ["Keep information confidential"], company_name="Example Co")
    doc = Document(BytesIO(content))
    all_text = "\n".join(p.text for p in doc.paragraphs)
    assert "NON-DISCLOSURE AGREEMENT" in all_text
    assert "Items to Confirm Before Signing" in all_text
    assert any("Appendix: Key Terms Provided" in p.text for p in doc.paragraphs)


def test_pdf_output_is_readable_and_contains_text():
    content = format_pdf(SAMPLE, "NDA", ["Keep information confidential"], company_name="Example Co")
    reader = PdfReader(BytesIO(content))
    extracted = "\n".join(page.extract_text() or "" for page in reader.pages)
    assert len(reader.pages) >= 1
    assert "NON-DISCLOSURE AGREEMENT" in extracted
    assert "Key Terms Provided" in extracted


def test_build_filename_only_allows_supported_extensions():
    assert build_filename("NDA / Draft", "docx") == "nda_draft.docx"
    try:
        build_filename("NDA", "exe")
    except ValueError:
        pass
    else:
        raise AssertionError("Unsupported extension should fail")


def test_html_preview_escapes_untrusted_text():
    preview = format_html_preview("# Title\n\n<script>alert(1)</script>\n\n- **Safe** term")
    assert "<h1>Title</h1>" in preview
    assert "&lt;script&gt;" in preview
    assert "<script>" not in preview
    assert "<strong>Safe</strong>" in preview


def test_pdf_and_docx_accept_uploaded_logo():
    logo = Image.new("RGBA", (120, 40), (24, 54, 92, 255))
    buffer = BytesIO()
    logo.save(buffer, format="PNG")
    logo_bytes = buffer.getvalue()
    docx_data = format_docx(SAMPLE, "NDA", logo_bytes=logo_bytes, company_name="Example Co")
    pdf_data = format_pdf(SAMPLE, "NDA", logo_bytes=logo_bytes, company_name="Example Co")
    assert Document(BytesIO(docx_data)).sections[0].header
    assert len(PdfReader(BytesIO(pdf_data)).pages) >= 1
